$(document).ready(function(){
    $( "span#header-width" ).html($("h1").width());
    $( "span#main-section-width" ).html($("div.section").width()); 
});